package fr.isep.foodapp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.media.DeniedByServerException;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import fr.isep.foodapp.DB.DBbreakfastAdapter;
import fr.isep.foodapp.DB.DBcollationsAdapter;
import fr.isep.foodapp.DB.DBdinnerAdapter;
import fr.isep.foodapp.DB.DBlunchAdapter;
import fr.isep.foodapp.DB.DBmanager;
import fr.isep.foodapp.Model.Food;
import fr.isep.foodapp.RecyclerViewAdapter.MyAdapter;

public class SearchFoodItems extends AppCompatActivity implements MyAdapter.onFoodListener {
    RecyclerView recyclerView;
    ArrayList<String> name, category, calorie;
    DBmanager DB;
    MyAdapter adapter;
    ImageButton back;
    ImageButton toAddNewFoodItem;
    
    List<Food> food;
    List<Food> foodLunch;
    
    DBbreakfastAdapter mDBbreakfastAdapter;
    DBlunchAdapter mDBlunchAdapter;
    DBdinnerAdapter mDBdinnerAdapter;
    DBcollationsAdapter mDBcollationsAdapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_search_food);
        back = findViewById(R.id.backButton);
        toAddNewFoodItem = findViewById(R.id.toAddNewFoodItem);
        
        DB = new DBmanager(this);

        mDBbreakfastAdapter = new DBbreakfastAdapter(this);
        mDBlunchAdapter = new DBlunchAdapter(this);
        mDBdinnerAdapter = new DBdinnerAdapter(this);
        mDBcollationsAdapter = new DBcollationsAdapter(this);
        
        name = new ArrayList<>();
        category = new ArrayList<>();
        calorie = new ArrayList<>();
        recyclerView = findViewById(R.id.foodRecyclerView);
        adapter = new MyAdapter(this, name, category, calorie, this::onFoodClick);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        food = new ArrayList<>();


        displaydata();


        toAddNewFoodItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(SearchFoodItems.this, AddFoodItem.class));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SearchFoodItems.this, MainActivity.class));
            }
        });

    }


    private void displaydata() {
        Cursor cursor = DB.getdata();
        if (cursor.getCount() == 0) {
            Toast.makeText(SearchFoodItems.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        } else {
            while (cursor.moveToNext()) {
                name.add(cursor.getString(0));
                category.add(cursor.getString(1));
                calorie.add(cursor.getString(2));
            }
        }
    }

    // Pour la fonction ci-dessous :
    // On demande à récupérer la valeur qui a été envoyé lorsqu'on a appuyé sur +Food,
    // Si par exemple la valeur est "BreakFast" cela veut dire que on a appuyé sur le bouton +Food
    // qui était disposé sur le Cardview du peti-déjeuner.
    // Alors lorsqu'on cliquera sur un item il sera ajouté au cardview correspondant.


    @Override
    public void onFoodClick(int position) {
        String nameFood = name.get(position).toString();
        String categoryFood = category.get(position).toString();
        String caloriesFood = calorie.get(position).toString();

        Bundle extras = getIntent().getExtras();
        if (extras.getString("KEY").contains("Break")) {
            Boolean checkinsertdata = mDBbreakfastAdapter.insertBreakFastData(nameFood, categoryFood, caloriesFood);
            if (checkinsertdata == true) {
                Toast.makeText(SearchFoodItems.this, "Food Inserted into breakfast", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SearchFoodItems.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(SearchFoodItems.this, MainActivity.class));
        } if (extras.getString("KEY").contains("Lunch")) {
            Boolean checkinsertdata = mDBlunchAdapter.insertLunchData(nameFood, categoryFood, caloriesFood);
            if (checkinsertdata == true) {
                Toast.makeText(SearchFoodItems.this, "Food Inserted into breakfast", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SearchFoodItems.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(SearchFoodItems.this, MainActivity.class));
        }if (extras.getString("KEY").contains("Dinner")) {
            Boolean checkinsertdata = mDBdinnerAdapter.insertDinnerData(nameFood, categoryFood, caloriesFood);
            if (checkinsertdata == true) {
                Toast.makeText(SearchFoodItems.this, "Food Inserted into dinner", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SearchFoodItems.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(SearchFoodItems.this, MainActivity.class));
        }
        if (extras.getString("KEY").contains("Collations")) {
            Boolean checkinsertdata = mDBcollationsAdapter.insertCollationsData(nameFood, categoryFood, caloriesFood);
            if (checkinsertdata == true) {
                Toast.makeText(SearchFoodItems.this, "Food Inserted into collations", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SearchFoodItems.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(SearchFoodItems.this, MainActivity.class));
        }

    }

}
