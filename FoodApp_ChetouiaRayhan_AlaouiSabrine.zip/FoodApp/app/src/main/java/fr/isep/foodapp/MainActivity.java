package fr.isep.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import fr.isep.foodapp.CalendarView.CalendarActivity;
import fr.isep.foodapp.DB.DBbreakfastAdapter;
import fr.isep.foodapp.DB.DBcollationsAdapter;
import fr.isep.foodapp.DB.DBdinnerAdapter;
import fr.isep.foodapp.DB.DBlunchAdapter;
import fr.isep.foodapp.Model.Food;
import fr.isep.foodapp.RecyclerViewAdapter.FoodAdapter;
import fr.isep.foodapp.RecyclerViewAdapter.collationsAdapter;
import fr.isep.foodapp.RecyclerViewAdapter.dinnerAdapter;
import fr.isep.foodapp.RecyclerViewAdapter.lunchAdapter;

public class MainActivity extends AppCompatActivity implements FoodAdapter.onBreakFastListener{

    LinearLayoutManager mLayoutManager;

    // chaque liste contiendra les élèments des repas de la journée
    List<Food> foodList;
    List<Food> foodListLunch;
    List<Food> foodListDinner;
    List<Food> foodListCollations;

    // Pour utiliser les recyclerView on fait appell aux adapteurs
    FoodAdapter foodAdapter;
    lunchAdapter mLunchAdapter;
    dinnerAdapter mDinnerAdapter;
    collationsAdapter mCollationsAdapter;

    RecyclerView.LayoutManager layoutManager;

    // declaations des recyclerViews
    RecyclerView breakFastRV;
    RecyclerView lunchRV;
    RecyclerView dinnerRV;
    RecyclerView collationsRV;

    //declarations des base de données lies aux repas de la journée
    DBbreakfastAdapter mDBbreakfastAdapter;
    DBlunchAdapter mDBlunchAdapter;
    DBdinnerAdapter mDBdinnerAdapter;
    DBcollationsAdapter mDBcollationsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDBbreakfastAdapter = new DBbreakfastAdapter(this);
        mDBlunchAdapter = new DBlunchAdapter(this);
        mDBdinnerAdapter = new DBdinnerAdapter(this);
        mDBcollationsAdapter = new DBcollationsAdapter(this);

        foodList = new ArrayList<>();
        foodListLunch = new ArrayList<>();
        foodListDinner = new ArrayList<>();
        foodListCollations = new ArrayList<>();

        breakFastRV = findViewById(R.id.breakfastRV);
        lunchRV = findViewById(R.id.lunchRV);
        dinnerRV = findViewById(R.id.dinnerRV);
        collationsRV = findViewById(R.id.collationsRV);

        foodAdapter = new FoodAdapter(this,foodList,this::onBreakFastFoodClick);
        mLunchAdapter = new lunchAdapter(this,foodListLunch,this::onLunchClick);
        mDinnerAdapter = new dinnerAdapter(this,foodListDinner,this::onDinnerClick);
        mCollationsAdapter = new collationsAdapter(this,foodListCollations,this::onCollationsClick);

        lunchRV.setAdapter(mLunchAdapter);
        breakFastRV.setAdapter(foodAdapter);
        dinnerRV.setAdapter(mDinnerAdapter);
        collationsRV.setAdapter(mCollationsAdapter);

        breakFastRV.setLayoutManager(new LinearLayoutManager(this));
        lunchRV.setLayoutManager(new LinearLayoutManager(this));
        dinnerRV.setLayoutManager(new LinearLayoutManager(this));
        collationsRV.setLayoutManager(new LinearLayoutManager(this));

        // Appel des fonctions pour remplir les liste à partir de la bdd
        displayBreakFastData();
        displayLunchData();
        displayDinnerData();
        displayCollationsData();

        ImageButton toCalendar = (ImageButton) findViewById(R.id.toCalendar);
        ImageButton toSearchFood = (ImageButton) findViewById(R.id.toSearchFood);
        ImageButton toShareFood = (ImageButton) findViewById(R.id.toShareFood);

        Button addFoodDinner = (Button) findViewById(R.id.buttonDinner);
        Button addFoodCollations = (Button) findViewById(R.id.buttonCollations);
        Button addFoodBreakFast = (Button) findViewById(R.id.buttonBreakFast);
        Button addFoodLunch = (Button) findViewById(R.id.buttonLunch);




        TextView dateTV = (TextView) findViewById(R.id.dateTextView);

        // L'objectif est de récupérer les dates à partir de la valeur reçu par le calendrier
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String dateValue = extras.getString("date");
            dateTV.setText(dateValue);
        }if (extras == null){
            dateTV.setText("TRACK YOUR FOOD ! ");
        }


        // Envoie sous forme de texte ce qui a été mangé
        toShareFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                String valueDinner = foodListDinner.toString();
                String valueLunch = foodListLunch.toString();
                String valueBreakFast = foodList.toString();
                String valueCollations = foodListCollations.toString();

                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "I have eaten the "+dateTV.getText()+"\n"+
                        "- for breakfast: " + valueBreakFast
                        +"\n"+"\n"+
                        "-for lunch: " + valueLunch
                        +"\n"+"\n"+
                        "-for dinner: " + valueDinner
                        +"\n"+"\n"+
                        "-My collations were: " + valueCollations
                );
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });


        addFoodBreakFast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchFoodItems.class);
                intent.putExtra("KEY","Breakfast");
                startActivity(intent);
            }
        });

        addFoodCollations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchFoodItems.class);
                intent.putExtra("KEY","Collations");
                startActivity(intent);
            }
        });

        addFoodDinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchFoodItems.class);
                intent.putExtra("KEY","Dinner");
                startActivity(intent);
            }
        });
        addFoodLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchFoodItems.class);
                intent.putExtra("KEY","Lunch");
                startActivity(intent);
            }
        });

        toCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CalendarActivity.class);
                startActivity(intent);
            }
        });


        toSearchFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchFoodItems.class);
                startActivity(intent);
            }
        });

    }


    private void displayBreakFastData()
    {
        Cursor cursor = mDBbreakfastAdapter.getBreakFastData();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                foodList.add(new Food(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
            }
        }
    }




    private void displayLunchData()
    {
        Cursor cursor = mDBlunchAdapter.getLunchData();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                foodListLunch.add(new Food(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
            }
        }
    }



    private void displayDinnerData()
    {
        Cursor cursor = mDBdinnerAdapter.getDinnerData();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                foodListDinner.add(new Food(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
            }
        }
    }


    private void displayCollationsData()
    {
        Cursor cursor = mDBcollationsAdapter.getCollationsData();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                foodListCollations.add(new Food(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
            }
        }
    }

    // L'ensemble des fonctions ci-dessous permette de supprimer les élèments en cliquant dessus

    @Override
    public void onBreakFastFoodClick(int position) {
        String deletedFoodNamefood = foodList.get(position).getFoodName();
        foodList.remove(position);
        mDBbreakfastAdapter.deleteBreakFastdata(deletedFoodNamefood);
        foodAdapter.notifyItemRemoved(position);
                }


    public void onLunchClick(int position) {
        String deletedFoodNamefood = foodListLunch.get(position).getFoodName();
        foodListLunch.remove(position);
        mDBlunchAdapter.deleteLunchdata(deletedFoodNamefood);
        mLunchAdapter.notifyItemRemoved(position);
    }

    public void onDinnerClick(int position) {
        String deletedFoodNamefood = foodListDinner.get(position).getFoodName();
        foodListDinner.remove(position);
        mDBdinnerAdapter.deleteDinnerdata(deletedFoodNamefood);
        mDinnerAdapter.notifyItemRemoved(position);
    }


    public void onCollationsClick(int position) {
        String deletedFoodNamefood = foodListCollations.get(position).getFoodName();
        foodListCollations.remove(position);
        mDBcollationsAdapter.deleteCollationsdata(deletedFoodNamefood);
        mCollationsAdapter.notifyItemRemoved(position);
    }

    }
