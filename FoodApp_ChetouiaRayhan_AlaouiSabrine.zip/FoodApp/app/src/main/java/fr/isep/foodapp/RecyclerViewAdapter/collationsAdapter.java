package fr.isep.foodapp.RecyclerViewAdapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.isep.foodapp.DB.DBdinnerAdapter;
import fr.isep.foodapp.Model.Food;
import fr.isep.foodapp.R;

public class collationsAdapter extends RecyclerView.Adapter<collationsAdapter.ViewHo> {
    Context context;
    List<Food> foodList;
    RecyclerView collationsRV;
    DBdinnerAdapter DBcollations;
    final View.OnClickListener onClickListener = new MyonClickListener();

    private onCollationsListener mOnCollationsListener;

    public static class ViewHo extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView rowFoodName;
        TextView rowCategoryName;
        TextView rowCaloriesCount;
        private collationsAdapter mCollationsAdapter;
        private onCollationsListener mOnCollationsListener;
        public ViewHo(@NonNull View itemView, onCollationsListener mOnCollationsListener) {
            super(itemView);
            rowCategoryName = itemView.findViewById(R.id.TrackCategoryName);
            rowFoodName = itemView.findViewById(R.id.TrackFoodName);
            rowCaloriesCount = itemView.findViewById(R.id.trackCalories);
            this.mOnCollationsListener = mOnCollationsListener;

            itemView.setOnClickListener(this);

        }

        public void setData(String name, String category , String calories){
            rowFoodName.setText(name);
            rowCategoryName.setText(category);
            rowCaloriesCount.setText(calories);

        }

        @Override
        public void onClick(View view) {
            mOnCollationsListener.onCollationsClick(getAdapterPosition());
        }
    }

    public collationsAdapter(Context context,List<Food> foodList,onCollationsListener mOnCollationsListener){
        this.context  =context;
        this.foodList = foodList;
        this.mOnCollationsListener = mOnCollationsListener ;
    }

    @NonNull
    @Override
    public collationsAdapter.ViewHo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_row_mini,parent,false);
        return new ViewHo(view,mOnCollationsListener);
    }

    @Override
    public void onBindViewHolder(@NonNull collationsAdapter.ViewHo holder, int position) {
        String name = foodList.get(position).getFoodName();
        String category = foodList.get(position).getCategoryName();
        String calories = foodList.get(position).getCaloriesNumber();

        holder.setData(name,category,calories);

    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    private class MyonClickListener implements View.OnClickListener {


        @Override
        public void onClick(View view) {
            int itemPosition = collationsRV.getChildLayoutPosition(view);
            String item = foodList.get(itemPosition).getFoodName();
            Toast.makeText(context, item,Toast.LENGTH_SHORT).show();

        }
    }

    public interface onCollationsListener{
        void onCollationsClick( int position);
    }
}
