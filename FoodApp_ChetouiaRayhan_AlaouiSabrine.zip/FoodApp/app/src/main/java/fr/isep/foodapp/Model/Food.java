package fr.isep.foodapp.Model;

public class Food {

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    private String foodName;
    private String categoryName;
    private String caloriesNumber;

    public Food(String foodName,String categoryName, String caloriesNumber){
        this.foodName = foodName;
        this.categoryName = categoryName;
        this.caloriesNumber = caloriesNumber;

    }


    @Override
    public String toString() {

        return foodName + " ("+ categoryName+")" + " , for 100g there is "+ caloriesNumber  +" calories" ;
    }

    public String getCaloriesNumber() {
        return caloriesNumber;
    }

    public void setCaloriesNumber(String caloriesNumber) {
        this.caloriesNumber = caloriesNumber;
    }


    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}


