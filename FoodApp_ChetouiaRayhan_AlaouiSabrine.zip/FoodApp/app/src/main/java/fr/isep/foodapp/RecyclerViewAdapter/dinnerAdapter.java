package fr.isep.foodapp.RecyclerViewAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.isep.foodapp.DB.DBdinnerAdapter;
import fr.isep.foodapp.DB.DBlunchAdapter;
import fr.isep.foodapp.Model.Food;
import fr.isep.foodapp.R;

public class dinnerAdapter extends RecyclerView.Adapter<dinnerAdapter.ViewHo> {
    Context context;
    List<Food> foodList;
    RecyclerView dinnerRV;
    DBdinnerAdapter DBdinner;
    final View.OnClickListener onClickListener = new MyonClickListener();

    private onDinnerListener mOnDinnerListener;

    public static class ViewHo extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView rowFoodName;
        TextView rowCategoryName;
        TextView rowCaloriesCount;
        private dinnerAdapter mDinnerAdapter;
        private onDinnerListener mOnDinnerListener;
        public ViewHo(@NonNull View itemView, onDinnerListener mOnDinnerListener) {
            super(itemView);
            rowCategoryName = itemView.findViewById(R.id.TrackCategoryName);
            rowFoodName = itemView.findViewById(R.id.TrackFoodName);
            rowCaloriesCount = itemView.findViewById(R.id.trackCalories);
            this.mOnDinnerListener = mOnDinnerListener;

            itemView.setOnClickListener(this);

        }

        public void setData(String name, String category , String calories){
            rowFoodName.setText(name);
            rowCategoryName.setText(category);
            rowCaloriesCount.setText(calories);

        }

        @Override
        public void onClick(View view) {
            mOnDinnerListener.onDinnerClick(getAdapterPosition());
        }
    }

    public dinnerAdapter(Context context,List<Food> foodList,onDinnerListener mOnDinnerListener){
        this.context  =context;
        this.foodList = foodList;
        this.mOnDinnerListener = mOnDinnerListener ;
    }

    @NonNull
    @Override
    public dinnerAdapter.ViewHo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_row_mini,parent,false);
        return new ViewHo(view,mOnDinnerListener);
    }

    @Override
    public void onBindViewHolder(@NonNull dinnerAdapter.ViewHo holder, int position) {
        String name = foodList.get(position).getFoodName();
        String category = foodList.get(position).getCategoryName();
        String calories = foodList.get(position).getCaloriesNumber();

        holder.setData(name,category,calories);

    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    private class MyonClickListener implements View.OnClickListener {


        @Override
        public void onClick(View view) {
            int itemPosition = dinnerRV.getChildLayoutPosition(view);
            String item = foodList.get(itemPosition).getFoodName();
            Toast.makeText(context, item,Toast.LENGTH_SHORT).show();

        }
    }

    public interface onDinnerListener{
        void onDinnerClick( int position);
    }
}
