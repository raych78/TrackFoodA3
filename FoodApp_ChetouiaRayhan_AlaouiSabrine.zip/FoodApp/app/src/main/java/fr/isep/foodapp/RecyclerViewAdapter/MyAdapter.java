package fr.isep.foodapp.RecyclerViewAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import fr.isep.foodapp.R;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context context;
    private ArrayList name_id, category_id, calorie_id;

    private onFoodListener mOnFoodListener;

    public MyAdapter(Context context, ArrayList name_id, ArrayList category_id, ArrayList calorie_id, onFoodListener mOnFoodListener) {
        this.context = context;
        this.name_id = name_id;
        this.category_id = category_id;
        this.calorie_id = calorie_id;
        this.mOnFoodListener = mOnFoodListener;
    }

    // On associe ici le layout qui remplira le recyclerview
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.recycler_view_row,parent,false);
        return new MyViewHolder(v,mOnFoodListener);
    }

    // On lie ici les valeur demandés
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name_id.setText(String.valueOf(name_id.get(position)));
        holder.category_id.setText(String.valueOf(category_id.get(position)));
        holder.calorie_id.setText(String.valueOf(calorie_id.get(position)));
    }

    // récupère la taille de la liste
    @Override
    public int getItemCount() {
        return name_id.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener{
        TextView name_id, category_id, calorie_id;
        onFoodListener mOnFoodListener;
        public MyViewHolder(@NonNull View itemView, onFoodListener mOnFoodListener) {
            super(itemView);
            name_id = itemView.findViewById(R.id.textname);
            category_id = itemView.findViewById(R.id.textcategory);
            calorie_id = itemView.findViewById(R.id.textcalorie);
            this.mOnFoodListener = mOnFoodListener;

            itemView.setOnClickListener(this);
        }

    // On créé ici une interface qui servira lorsqu'n cliquera sur les items de nourittures
        @Override
        public void onClick(View view) {
            mOnFoodListener.onFoodClick(getAdapterPosition());
        }
    }

    public interface onFoodListener{
        void onFoodClick( int position);
    }

}