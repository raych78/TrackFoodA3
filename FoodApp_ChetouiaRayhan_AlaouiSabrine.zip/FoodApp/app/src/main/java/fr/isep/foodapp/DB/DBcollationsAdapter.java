package fr.isep.foodapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import fr.isep.foodapp.Model.Food;

public class DBcollationsAdapter extends SQLiteOpenHelper {
    List<Food> foodList = new ArrayList<>();

    public DBcollationsAdapter(Context context) {
        super(context, "collations.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table collationsDetails(name TEXT primary key,category TEXT, calorie TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists collationsDetails");
    }

    public Boolean insertCollationsData(String name, String Category, String calorie)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("category", Category);
        contentValues.put("calorie", calorie);
        long result = DB.insert("collationsDetails", null, contentValues);
        if(result==-1)
        {
            return  false;
        }
        else
        {
            return true;
        }
    }

    public Cursor getCollationsData()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from collationsDetails", null);
        return cursor;
    }



    public Boolean deleteCollationsdata(String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from collationsDetails where name = ?", new String[]{name});
        if(cursor.getCount()>0)
        {
            long result = DB.delete("collationsDetails", "name=?", new String[]{name});
            if(result==-1)
            {
                return  false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }

    }

}
