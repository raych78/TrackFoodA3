package fr.isep.foodapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import fr.isep.foodapp.Model.Food;


// La Classe sert à manager tout ce qui sera fait dans la BDD des items de nouritture ajoutés dans la page searchFood
public class DBmanager extends SQLiteOpenHelper {
    List<Food> foodList = new ArrayList<>();


    public DBmanager(Context context) {
        super(context, "Userdata.db", null, 1);
    }
// On créé ici la table avec trois colonnes : le nom, la categorie et le nombre de calories
    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userdetails(name TEXT primary key,category TEXT, calorie TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists Userdetails");
    }

    // Fonction pour ajouter des données
    public Boolean insertuserdata(String name, String Category, String calorie)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("category", Category);
        contentValues.put("calorie", calorie);
        long result = DB.insert("Userdetails", null, contentValues);
        if(result==-1)
        {
            return  false;
        }
        else
        {
            return true;
        }
    }

    // Fonction pour récupérer les données
    public Cursor getdata()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from Userdetails", null);
        return cursor;
    }

    // Fonction pour supprimer des données
    public Boolean deleteuserdata(String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userdetails where name = ?", new String[]{name});
        if(cursor.getCount()>0)
        {
            long result = DB.delete("Userdetails", "name=?", new String[]{name});
            if(result==-1)
            {
                return  false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }

    }

}