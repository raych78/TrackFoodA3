package fr.isep.foodapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

import fr.isep.foodapp.Model.Food;

public class DBbreakfastAdapter extends SQLiteOpenHelper {
    List<Food> foodList = new ArrayList<>();

    public DBbreakfastAdapter(Context context) {
        super(context, "breakFastDB.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table breakfastDetails(name TEXT primary key,category TEXT, calorie TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists breakFastDetails");
    }

    public Boolean insertBreakFastData(String name, String Category, String calorie)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("category", Category);
        contentValues.put("calorie", calorie);
        long result = DB.insert("breakFastDetails", null, contentValues);
        if(result==-1)
        {
            return  false;
        }
        else
        {
            return true;
        }
    }

    public Cursor getBreakFastData()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from breakFastDetails", null);
        return cursor;
    }



    public Boolean deleteBreakFastdata(String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from breakFastDetails where name = ?", new String[]{name});
        if(cursor.getCount()>0)
        {
            long result = DB.delete("breakFastDetails", "name=?", new String[]{name});
            if(result==-1)
            {
                return  false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }

    }

}
