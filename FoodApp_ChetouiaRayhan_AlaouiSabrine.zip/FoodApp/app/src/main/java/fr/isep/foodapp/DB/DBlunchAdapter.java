package fr.isep.foodapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import fr.isep.foodapp.Model.Food;

public class DBlunchAdapter extends SQLiteOpenHelper {
    List<Food> foodList = new ArrayList<>();

    public DBlunchAdapter(Context context) {
        super(context, "lunch.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table lunchDetails(name TEXT primary key,category TEXT, calorie TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists lunchDetails");
    }

    public Boolean insertLunchData(String name, String Category, String calorie)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("category", Category);
        contentValues.put("calorie", calorie);
        long result = DB.insert("lunchDetails", null, contentValues);
        if(result==-1)
        {
            return  false;
        }
        else
        {
            return true;
        }
    }

    public Cursor getLunchData()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from lunchDetails", null);
        return cursor;
    }



    public Boolean deleteLunchdata(String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from lunchDetails where name = ?", new String[]{name});
        if(cursor.getCount()>0)
        {
            long result = DB.delete("lunchDetails", "name=?", new String[]{name});
            if(result==-1)
            {
                return  false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }

    }

}