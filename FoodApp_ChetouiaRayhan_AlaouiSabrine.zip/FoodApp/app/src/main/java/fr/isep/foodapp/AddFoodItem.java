package fr.isep.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import fr.isep.foodapp.DB.DBmanager;

public class AddFoodItem extends AppCompatActivity {
    EditText name, category, calorie;
    Button insert, view, delete;
    DBmanager DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food_item);

        name = findViewById(R.id.name);
        category= findViewById(R.id.category);
        calorie = findViewById(R.id.calorie);
        insert = findViewById(R.id.btnInsert);
        view = findViewById(R.id.btnView);
        delete = findViewById(R.id.btnDelete);

        DB = new DBmanager(this);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddFoodItem.this, SearchFoodItems.class));
            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT = name.getText().toString();
                String categoryTXT = category.getText().toString();
                String calorieTXT = calorie.getText().toString();

                // il sera vérifié si les données sont bien intégrés à la bdd grâce à Toast
                Boolean checkinsertdata  = DB.insertuserdata(nameTXT,categoryTXT,calorieTXT);
                if(checkinsertdata==true)
                {
                    Toast.makeText(AddFoodItem.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(AddFoodItem.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
                }

                startActivity(new Intent(AddFoodItem.this, SearchFoodItems.class));
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT = name.getText().toString();

                Boolean checkdeletedata  = DB.deleteuserdata(nameTXT);
                if(checkdeletedata==true)
                {
                    Toast.makeText(AddFoodItem.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(AddFoodItem.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}